create table product(
    title varchar,
    price int,
    category varchar,
    inStock Boolean
);